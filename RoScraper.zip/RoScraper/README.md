# RoScraper
A Cool Tool That Finds Ownerless Groups on ROBLOX For Free!!

![Screenshot](screenshot.png)
(server: hetzner ex62-nvme (de), proxies: awmproxy vip, threads: 500)


# Configuration
- `threadCount`: Amount of Threads Used in Finding Groups!!
- `displayErrors`: Tool Will Also Display Errors with The RoScraper Through Discord Webhooks!!
- `isLooped`: Scanner Will Be Set to Minimum Range if Max Range Reached!!
- `webhookUrl`: Groups That Will Be Found Will Be Sent By An Embed Using Discord Webhooks!!
- `minMemberCount`: Groups with Members Below The Amount Give Won't Be Shown, Best to Set This to 0!!
- `range`: RoScraper Will Scan The Groups Within The 'min' and 'max' IDs!!

# Output
Unclaimed Groups That Will RoScraper Found Will Be Logged to a File Named `found.csv` With The Following Columns:
- Id
- Member count
- Url
- Name

# Usage
- Install The Latest Python On [This Site](https://www.python.org/downloads/). While Python is Being Installed, Click 'Add to PATH'!!
- Go [To This Site](https://github.com/h0nde/roblox-group-scraper/archive/main.zip). After, Go To File Explorer, Right Click The File Name and Click Extract!!
- Set up Config.json, Make Sure All Fields Are Filled!!
- Add Your Proxies (HTTP/S Version) to Proxies.txt, You Can Find Proxies [Here](https://proxyscrape.com/). Paid Are Required, Free is Fine, But, RoScraper Will Find Groups Very Slow!!
- Launch Scraper.bat and Wait Until The Group Finder Finds a Group!!
